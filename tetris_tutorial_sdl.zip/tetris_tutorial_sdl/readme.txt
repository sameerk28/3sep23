--------------------------------------------------------------

Tutorial from gametuto.com by Javier L�pez L�pez (javilop.com)

--------------------------------------------------------------

The sourcecode is under the �Creative Commons - Attribution 3.0 Unported�. That means you can copy, distribute and transmit the work and to adapt it. But you must attribute the work (but not in any way that suggests that they endorse you or your use of the work). The way of attribute the work is up to you. You can just mention me (Javier L�pez). A backlink would be also appreciated.

--------------------------------------------------------------

Keys
----

    * ESC = Quit the game
    * z = Rotate the piece
    * x = Drop piece
    * Left, Right, Down = I will not offend your intelligence



